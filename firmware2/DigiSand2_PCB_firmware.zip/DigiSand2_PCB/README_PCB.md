# DigiSand2_PCB: firmware for the DigiSand PCB v2.1

A copy of firmware/DigiSand2 with only the hardware-specific parts changed.
The student's original folder is untouched.

## Changes
- Pins (top of DigiSand2_PCB.ino): buttons Up D2, Menu D3, Down D4; matrix CLK D6, CS D7, DIN D8; speaker D9.
- Sensor: miniLSM6.h replaces mini6050.h (the board has an LSM6DS3 at I2C 0x6A, not an MPU6050).
  Same methods, so the sand code is unchanged. mpu.isConnected() checks the chip ID.
- Battery: readBattery() reads the battery through the R14/R15 divider on ADC7 (board v2.1) with the
  internal 1.1 V reference. ADC_REF_MV can be adjusted to calibrate (the reference varies +-10% per chip).
  For a v2 board without the divider, uncomment #define NO_BATTERY_SENSE.
- Bug fix: the battery percentage overflowed (int8_t) above about 3.84 V and showed 00% on a full battery.
- Fix: if the battery reads empty at power-on (or no battery is fitted and it runs from USB), the empty
  icon now blinks for about 6 seconds and then the clock starts. The original looped forever on that icon.
- Fix: the sensor check accepts both IDs, 0x69 (LSM6DS3) and 0x6A (LSM6DS3TR-C, the part on the BOM).

## Kept as the student wrote it (change if you like)
- battery_min 3000 / battery_max 3800 mV: everything above 3.8 V shows as 99%.

## Compile (Arduino IDE)
- Board package: MiniCore. Board: ATmega328. Clock: External 8 MHz. Variant: 328P.
- Libraries: the ones in /libraries of this repo (EncButton, GyverMAX7219, GyverGFX, GyverIO, EEManager).
- DigiSand2_PCB_8MHz.hex is a ready-made build of this folder (the same file the simulator runs).

## To check on the first real board
- Matrix cable order on J4 (CLK/CS/DIN). Change CK_PIN/CS_PIN/DT_PIN if your cable differs.
- Button order on J3 (swap BTN pins if Up/Down are reversed).
- Tilt direction: if the sand falls the wrong way, change setMpuOrientation(...) in setup().
