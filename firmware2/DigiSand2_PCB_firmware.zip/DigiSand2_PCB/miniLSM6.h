#pragma once
// Driver for the LSM6DS3 accelerometer on the DigiSand PCB (U6, I2C address 0x6A).
// Drop-in replacement for mini6050.h: same public methods, so the rest of the
// firmware is unchanged. At +-2 g the LSM6DS3 gives 0.061 mg/LSB (~16393 LSB/g),
// practically the same scale as the MPU6050 (16384 LSB/g).
#include <Arduino.h>
#include <Wire.h>

#define LSM6_ADDR 0x6A       // SDO/SA0 tied to GND on the PCB
#define LSM6_WHO_AM_I 0x0F   // reads 0x69 on LSM6DS3, 0x6A on LSM6DS3TR-C
#define LSM6_CTRL1_XL 0x10   // accelerometer: data rate + full scale
#define LSM6_CTRL3_C 0x12    // BDU + register auto-increment
#define LSM6_OUTX_L_XL 0x28  // X, Y, Z: 6 bytes, little-endian

struct DirXyz {
    uint8_t axis;
    int8_t dir;
};

class MiniLSM6 {
   public:
    void begin() {
        writeReg(LSM6_CTRL3_C, 0x44);   // BDU=1, IF_INC=1
        writeReg(LSM6_CTRL1_XL, 0x40);  // 104 Hz, +-2 g
    }

    // true if the chip answers with the right ID (useful for a quick hardware test)
    bool isConnected() {
        Wire.beginTransmission(LSM6_ADDR);
        Wire.write(LSM6_WHO_AM_I);
        if (Wire.endTransmission(false) != 0) return false;
        Wire.requestFrom(LSM6_ADDR, 1, true);
        if (!Wire.available()) return false;
        uint8_t id = Wire.read();
        return id == 0x69 || id == 0x6A;
    }

    void setX(DirXyz dir) { dirx = dir; }
    void setY(DirXyz dir) { diry = dir; }
    void setZ(DirXyz dir) { dirz = dir; }

    bool update(uint16_t prd = 30) {
        if ((uint16_t)((uint16_t)millis() - tmr) >= prd) {
            tmr = millis();

            Wire.beginTransmission(LSM6_ADDR);
            Wire.write(LSM6_OUTX_L_XL);
            Wire.endTransmission(false);
            Wire.requestFrom(LSM6_ADDR, 6, true);
            for (byte i = 0; i < 3; i++) {
                uint8_t lo = Wire.read();
                uint8_t hi = Wire.read();
                raw[i] = (int16_t)((hi << 8) | lo);
            }

            int magr = getDir(dirz) * 255L / 16000L;
            if (magr < 0) magr = -magr;
            mag = 255 - min(magr, 255);

            angle = degrees(atan2(getDir(dirx), getDir(diry)));
            return 1;
        }
        return 0;
    }

    int16_t getAx() { return getDir(dirx); }
    int16_t getAy() { return getDir(diry); }
    int16_t getAz() { return getDir(dirz); }

    int8_t getDir() { return abs(getAngle()) < 90 ? 1 : -1; }
    int16_t getAngle() { return angle; }
    uint8_t getMag() { return mag; }

    bool isStable() { return abs(getAngle()) < 5; }

   private:
    uint16_t tmr;
    int16_t raw[3];
    int16_t angle;
    uint8_t mag;
    DirXyz dirx, diry, dirz;

    int16_t getDir(DirXyz& dir) { return raw[dir.axis] * dir.dir; }

    void writeReg(uint8_t reg, uint8_t val) {
        Wire.beginTransmission(LSM6_ADDR);
        Wire.write(reg);
        Wire.write(val);
        Wire.endTransmission(true);
    }
};
