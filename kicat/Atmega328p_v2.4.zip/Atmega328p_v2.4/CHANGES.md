# Sand clock board v2.4: changes from the student's v1 (1 Feb 2026)

Checked with KiCad 9 after every change:
- Design rule check (DRC): 0 errors, 0 unconnected items. Only cosmetic silkscreen-text warnings remain.
- Schematic check (ERC): same harmless warnings as v1 (no power-flag symbols).
- Schematic and board match exactly (schematic parity check passes).

## Fixes
1. Battery charging: R7 (10k on the charger's TS pin) now goes to GND instead of VIN.
   Before, the charger saw "battery too cold" and refused to charge.
2. Real on/off switch: SW1 no longer sits in the USB 5 V line. It now controls a new
   P-MOSFET load switch Q1 (AO3401A, C15127) with gate pull-up R12 (100k, C25803).
   - OFF: regulator, processor, sensor and LED matrix are all unpowered. The battery is
     still charged when USB is plugged in, and the charge LEDs still work.
   - ON: everything runs from the battery, or from USB when it's plugged in.
   - SW1 now carries almost no current (before, up to ~0.9 A flowed through a 100 mA switch).
   - ON = slider connecting pins 2 and 3 (same direction as the old design).
3. LED matrix power: J4 pin 4 now comes from the switched battery rail (SYS, about 3.5-4.2 V)
   instead of USB 5 V only, so the matrix works on battery.
4. Speaker protection: R13 (150 ohm, C25208) added between D9 and the speaker pin (J3 pin 4).
   It limits the pin current to about 20 mA. That's safe for a piezo or an 8 ohm speaker.
5. Crystal: Y1 changed to 8 MHz (C518154). At 3.3 V the ATmega328P is only specified up to about
   13 MHz, so 8 MHz keeps it in spec. Use the "8 MHz external" setting when loading the bootloader.
6. Removed the leftover unconnected J102 footprint (it sat outside the board).
7. Fixed stale part numbers on the board file so they match the schematic
   (D2 C84260, D3 C19171391, J1 C3445864, J101 C41376035).

## Added in v2.1
8. SAFETY: charger U2 changed from BQ24078 to BQ24072 (C140288). The BQ24078 charges to 4.35 V,
   meant for high-voltage cells; a standard 3.7 V LiPo must stop at 4.2 V. Same footprint and pins
   (pin 15 is TD on the BQ24072, tied to GND = charge termination enabled).
   Do not charge a standard LiPo on any board fitted with the BQ24078.
9. Battery level measurement: R14 1M (C22935, top) + R15 100k (C25803, bottom) + C23 100nF (C1591, bottom)
   divide the battery voltage by 11 into ADC7 (U1 pin 22). Firmware DigiSand2_PCB reads it with the
   internal 1.1 V reference. Draws about 4 uA from the battery, even when switched off.
10. Battery net named BAT; R13 symbol orientation corrected so the schematic matches the board exactly.

## Added in v2.3: smallest connectors (JST SUR, 0.8 mm pitch, side entry, 1.75 mm high)
11. J3 (buttons/speaker) and J4 (matrix): JST PH 2.0 mm -> JST SUR SM05B-SURS-TF (C5441000).
12. J2 (battery): JST PH 2.0 mm -> JST SUR SM02B-SURS-TF (C566239).
    All three are the same type now. Pin order unchanged. Each sits where the old one was, with its
    cable opening facing the nearest board edge (J2 right, J3 left, J4 top), so cables run flat along
    the bottom of the board. Their wiring and the power-switch control wire (PWR_EN) were re-routed.
    Cables: SUR headers take two cable types.
      - SUR housings (insulation displacement): 0.5 A with AWG 32 wire, 0.2 A with AWG 36.
      - SUH housings (crimp): 1.0 A with AWG 28 wire.
    Use SUH / AWG 28 for the battery (charging is 0.30 A, see 13) and the matrix (power pin carries up to ~0.2 A).
    Battery: needs a 2-pin SUR/SUH plug with + on pin 1. Check polarity before plugging in.

## Added in v2.4 (parts list only: board copper, Gerbers and placement file are unchanged)
13. R6 (charger ISET) 1.8k -> 3k (C4211, Basic part). Charge current drops from 0.49 A to 0.30 A,
    giving the small SUR battery connector a safe margin. A 500 mAh battery charges in about 1 h 45 min.
    R3 (input current limit) stays 1.8k.

## Ordering at JLCPCB
- Gerbers: production/Atmega328p_gerbers.zip (4-layer, 32 x 32 mm, 1.6 mm)
- BOM: production/Atmega328p_bom.csv
- Parts on both sides: J2, J3, J4, J101 (as before) plus R15 and C23 are on the bottom.
- Placement (CPL): production/Atmega328p_positions.csv
- Check the part orientations in JLCPCB's placement preview before paying, especially Q1.
- Order the minimum quantity first (2 assembled boards).
- SW1 (slide switch) is through-hole. Either choose through-hole assembly or solder it yourself.

## Known limits
- MAX7219 is specified from 4.0 V. On battery the rail is about 3.5-4.2 V. Most MAX7219 modules
  still work at that voltage, a little dimmer, especially near the end of the battery charge.
